var json1 = {
    
    "jsExpert": [
        
        {
            
            "position" : "JavaScript Expert",
            "name" : "James Croft",
            "age" : 24
            
        },
        {
            
            "position" : "JavaScript Expert",
            "name" : "Josh McWillson",
            "age" : 34
            
        }
        
    ]
    
};

var json2 = {
    
    "phpExpert": [
        
        {
            
            "position" : "PHP Expert",
            "name" : "Billy John",
            "age" : 21
            
        },
        {
            
            "position" : "PHP Expert",
            "name" : "Laura Less",
            "age" : 32
            
        },
        {
            
            "position" : "PHP Expert",
            "name" : "Stephanie Dockson",
            "age" : 28
            
        }
        
    ]
    
};











